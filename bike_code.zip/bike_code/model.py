# -*- coding: utf-8 -*-
"""
Created on Tue Dec  8 17:54:58 2020

@author: Jerry
"""


import pandas as pd
import numpy as np
import lightgbm as lgb
import xgboost as xgb
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold,GridSearchCV
from sklearn.model_selection import StratifiedKFold
from catboost import CatBoostRegressor
from sklearn.ensemble import RandomForestRegressor
from logger import logger
from sklearn.metrics import mean_squared_error


class LGBSBBTree():
    """Stacking,
        Bootstap,
        Bagging----SBBTree"""
    def __init__(self, params, stacking_num, bagging_num, bagging_test_size, num_boost_round, early_stopping_rounds):
        """
        Initializes the SBBTree.
        Args:
          params : lgb params.
          stacking_num : k_flod stacking.
          bagging_num : bootstrap num.
          bagging_test_size : bootstrap sample rate.
          num_boost_round : boost num.
          early_stopping_rounds : early_stopping_rounds.
        """
        self.params = params
        self.stacking_num = stacking_num
        self.bagging_num = bagging_num
        self.bagging_test_size = bagging_test_size
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds

        self.model = lgb
        self.stacking_model = []
        self.bagging_model = []
        logger.info('LightGBM Model:%s'%(self.model))
        logger.info('params:%s'%(self.params))
        logger.info('stacking_num:%s'%(self.stacking_num) )
        logger.info('bagging_num:%s'%(self.bagging_num) )
        logger.info('bagging_test_size:%s'%(self.bagging_test_size))
        logger.info('num_boost_round:%s'%(self.num_boost_round))
        logger.info('early_stopping_rounds:%s'%(self.early_stopping_rounds))
    def fit(self, X, y):
        """ fit model. """
            
        if self.stacking_num > 1:
             
            layer_train = np.zeros((X.shape[0], 2))
            self.SK = KFold(n_splits=self.stacking_num, shuffle=True, random_state=1)
            for k,(train_index, test_index) in enumerate(self.SK.split(X, y)):
                X_train = X[train_index]
                y_train = y[train_index]
                X_test = X[test_index]
                y_test = y[test_index]

                lgb_train = lgb.Dataset(X_train, y_train)
                lgb_eval = lgb.Dataset(X_test, y_test, reference=lgb_train)

                gbm = lgb.train(self.params,
                            lgb_train,
                            num_boost_round=self.num_boost_round,
                            valid_sets=lgb_eval,
                            verbose_eval=1000,
                            early_stopping_rounds=self.early_stopping_rounds)

                self.stacking_model.append(gbm)
                
                pred_y = gbm.predict(X_test, num_iteration=gbm.best_iteration)
                logger.info('rmsle %s:%s'%(k, rmsle(pred_y, y_test)))
                layer_train[test_index, 1] = pred_y
                if k == 0:
                    rmsles=rmsle(pred_y, y_test)
                else:
                    rmsles+=rmsle(pred_y, y_test)
            logger.info('stacking_mean_rmsle :%s'%(rmsles/self.bagging_num))
            X = np.hstack((X, layer_train[:,1].reshape((-1,1)))) 
        else:
            pass
        for bn in range(self.bagging_num):
  
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=self.bagging_test_size, random_state=bn)

            lgb_train = lgb.Dataset(X_train, y_train)
            lgb_eval = lgb.Dataset(X_test, y_test, reference=lgb_train)

            gbm = lgb.train(self.params,
                        lgb_train,
                        num_boost_round=10000,
                        valid_sets=lgb_eval,
                        verbose_eval=1000,
                        early_stopping_rounds=self.early_stopping_rounds)

            self.bagging_model.append(gbm)
            pred_y = gbm.predict(X_test, num_iteration=gbm.best_iteration)
            logger.info('rmsle %s:%s'%(bn, rmsle(pred_y, y_test)))
            if bn == 0:
                rmsles=rmsle(pred_y, y_test)
            else:
                rmsles+=rmsle(pred_y, y_test)
        logger.info('bagging_mean_rmsle :%s'%(rmsles/self.bagging_num))            
    def predict(self, X_pred):
        """ predict test data. """
        if self.stacking_num > 1:
            test_pred = np.zeros((X_pred.shape[0], self.stacking_num))
            for sn,gbm in enumerate(self.stacking_model):
                pred = gbm.predict(X_pred, num_iteration=gbm.best_iteration)
                test_pred[:, sn] = pred
            X_pred = np.hstack((X_pred, test_pred.mean(axis=1).reshape((-1,1))))  
        else:
            pass 
        for bn,gbm in enumerate(self.bagging_model):
            pred = gbm.predict(X_pred, num_iteration=gbm.best_iteration)
            if bn == 0:
                pred_out=pred
            else:
                pred_out+=pred
        return pred_out/self.bagging_num
    
class LGB_SBBTree():
    """Stacking,
        Bootstap,
        Bagging----SBBTree"""
    def __init__(self, params, stacking_num, bagging_num, bagging_test_size, num_boost_round, early_stopping_rounds):
        """
        Initializes the SBBTree.
        Args:
          params : LGB params.
          stacking_num : k_flod stacking.
          bagging_num : bootstrap num.
          bagging_test_size : bootstrap sample rate.
          num_boost_round : boost num.
          early_stopping_rounds : early_stopping_rounds.
        """
        self.params = params
        self.stacking_num = stacking_num
        self.bagging_num = bagging_num
        self.bagging_test_size = bagging_test_size
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds

        self.model = lgb
        self.stacking_model = []
        self.bagging_model = []
        logger.info('LGB_SBBTree Model:%s'%(self.model))
        logger.info('params:%s'%(self.params))
        logger.info('stacking_num:%s'%(self.stacking_num) )
        logger.info('bagging_num:%s'%(self.bagging_num) )
        logger.info('bagging_test_size:%s'%(self.bagging_test_size))
        logger.info('num_boost_round:%s'%(self.num_boost_round))
        logger.info('early_stopping_rounds:%s'%(self.early_stopping_rounds))
    def fit(self, X, y):
        """ fit model. """
        if self.stacking_num > 1:
            layer_train = np.zeros((X.shape[0], 2))
            self.SK = KFold(n_splits=self.stacking_num, shuffle=True, random_state=1)
            for k,(train_index, test_index) in enumerate(self.SK.split(X, y)):
                X_train = X[train_index]
                y_train = y[train_index]
                X_test = X[test_index]
                y_test = y[test_index]

                param_test1 = {
                        	 'max_depth':[5,6,8],
                        	  'n_estimators ':[500,1000,2000],
                        	 'learning_rate':[0.05,0.1],}
            
                gsearch = GridSearchCV(lgb.LGBMRegressor(**self.params),
                        param_grid = param_test1, scoring='neg_mean_squared_error', cv=5, n_jobs=-1)
                gsearch.fit(X_train, y_train)
                logger.info('LGB_SBBTree Stacking:%s'%(k))
                # logger.info('gsearch.cv_results:%s'%(gsearch.cv_results_))
                logger.info('gsearch.best_params_:%s'%(gsearch.best_params_))
                logger.info('gsearch.best_score_:%s'%(gsearch.best_score_))
                logger.info('rmsle:%s'%(rmsle(gsearch.best_estimator_.predict(X_test),y_test)))
                self.stacking_model.append(gsearch.best_estimator_)

                pred_y = gsearch.best_estimator_.predict(X_test)
                layer_train[test_index, 1] = pred_y
                if k == 0:
                    rmsles=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
                else:
                    rmsles+=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
            logger.info('stacking_mean_rmsle :%s'%(rmsles/self.bagging_num))
            X = np.hstack((X, layer_train[:,1].reshape((-1,1)))) 
        else:
            pass
        for bn in range(self.bagging_num):
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=self.bagging_test_size, random_state=bn)

            param_test1 = {
                        	 'max_depth':[3,6,8],
                        	 'n_estimators ':[500,1000,2000],
                        	 'learning_rate':[0.05,0.1],}
        
            gsearch = GridSearchCV(lgb.LGBMRegressor(**self.params),
                    param_grid = param_test1, scoring='neg_mean_squared_error', cv=5, n_jobs=-1)
            gsearch.fit(X_train, y_train)
            logger.info('LGB_SBBTree Bagging:%s'%(bn))
            # logger.info('gsearch.cv_results:%s'%(gsearch.cv_results_))
            logger.info('gsearch.best_params_:%s'%(gsearch.best_params_))
            logger.info('gsearch.best_score_:%s'%(gsearch.best_score_))
            logger.info('rmsle:%s'%(rmsle(gsearch.best_estimator_.predict(X_test),y_test)))            
            self.bagging_model.append(gsearch.best_estimator_)
            if bn == 0:
                rmsles=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
            else:
                rmsles+=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
        logger.info('bagging_mean_rmsle :%s'%(rmsles/self.bagging_num))  
    def predict(self, X_pred):
        """ predict test data. """
        if self.stacking_num > 1:
            test_pred = np.zeros((X_pred.shape[0], self.stacking_num))
            for sn,gsearch in enumerate(self.stacking_model):
                pred = gsearch.predict(X_pred)
                test_pred[:, sn] = pred
            X_pred = np.hstack((X_pred, test_pred.mean(axis=1).reshape((-1,1))))  
        else:
            pass 
        for bn,gsearch in enumerate(self.bagging_model):
            pred = gsearch.predict(X_pred)
            if bn == 0:
                pred_out=pred
            else:
                pred_out+=pred
        return pred_out/self.bagging_num       
    

class XGBSBBTree():
    """Stacking,
        Bootstap,
        Bagging----SBBTree"""
    def __init__(self, params, stacking_num, bagging_num, bagging_test_size, num_boost_round, early_stopping_rounds):
        """
        Initializes the SBBTree.
        Args:
          params : XGB params.
          stacking_num : k_flod stacking.
          bagging_num : bootstrap num.
          bagging_test_size : bootstrap sample rate.
          num_boost_round : boost num.
          early_stopping_rounds : early_stopping_rounds.
        """
        self.params = params
        self.stacking_num = stacking_num
        self.bagging_num = bagging_num
        self.bagging_test_size = bagging_test_size
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds

        self.model = xgb
        self.stacking_model = []
        self.bagging_model = []
        logger.info('XGBOOST Model:%s'%(self.model))
        logger.info('params:%s'%(self.params))
        logger.info('stacking_num:%s'%(self.stacking_num) )
        logger.info('bagging_num:%s'%(self.bagging_num) )
        logger.info('bagging_test_size:%s'%(self.bagging_test_size))
        logger.info('num_boost_round:%s'%(self.num_boost_round))
        logger.info('early_stopping_rounds:%s'%(self.early_stopping_rounds))
    def fit(self, X, y):
        """ fit model. """
        if self.stacking_num > 1:
            layer_train = np.zeros((X.shape[0], 2))
            self.SK = KFold(n_splits=self.stacking_num, shuffle=True, random_state=1)
            for k,(train_index, test_index) in enumerate(self.SK.split(X, y)):
                X_train = X[train_index]
                y_train = y[train_index]
                X_test = X[test_index]
                y_test = y[test_index]

                xgb_train = self.model.DMatrix(X_train, label=y_train)
                xgb_eval = self.model.DMatrix(X_test, label=y_test)
                watchlist = [(xgb_train, 'train'), (xgb_eval, 'valid')]
                xgb = self.model.train(self.params,
                            xgb_train,
                            num_boost_round=self.num_boost_round,
                            evals=watchlist,
                            verbose_eval=1000,
                            early_stopping_rounds=self.early_stopping_rounds)

                self.stacking_model.append(xgb)

                pred_y = xgb.predict(xgb_eval, ntree_limit=xgb.best_ntree_limit)
                logger.info('rmsle %s:%s'%(k, rmsle(pred_y, y_test)))
                layer_train[test_index, 1] = pred_y
                if k == 0:
                    rmsles=rmsle(pred_y, y_test)
                else:
                    rmsles+=rmsle(pred_y, y_test)
            logger.info('stacking_mean_rmsle :%s'%(rmsles/self.bagging_num))
            X = np.hstack((X, layer_train[:,1].reshape((-1,1)))) 
        else:
            pass
        for bn in range(self.bagging_num):
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=self.bagging_test_size, random_state=bn)

            xgb_train = self.model.DMatrix(X_train, label=y_train)
            xgb_eval = self.model.DMatrix(X_test, label=y_test)
            watchlist = [(xgb_train, 'train'), (xgb_eval, 'valid')]
            xgb = self.model.train(self.params,
                        xgb_train,
                        num_boost_round=10000,
                        evals=watchlist,
                        verbose_eval=1000,
                        early_stopping_rounds=self.early_stopping_rounds)
            pred_y = xgb.predict(xgb_eval, ntree_limit=xgb.best_ntree_limit)
            logger.info('rmsle %s:%s'%(bn, rmsle(pred_y, y_test)))
            self.bagging_model.append(xgb)
            if bn == 0:
                rmsles=rmsle(pred_y, y_test)
            else:
                rmsles+=rmsle(pred_y, y_test)
        logger.info('bagging_mean_rmsle :%s'%(rmsles/self.bagging_num)) 
    def predict(self, X_pred):
        """ predict test data. """
        if self.stacking_num > 1:
            test_pred = np.zeros((X_pred.shape[0], self.stacking_num))
            for sn,xgb in enumerate(self.stacking_model):
                pred = xgb.predict(self.model.DMatrix(X_pred), ntree_limit=xgb.best_ntree_limit)
                test_pred[:, sn] = pred
            X_pred = np.hstack((X_pred, test_pred.mean(axis=1).reshape((-1,1))))  
        else:
            pass 
        for bn,xgb in enumerate(self.bagging_model):
            pred = xgb.predict(self.model.DMatrix(X_pred), ntree_limit=xgb.best_ntree_limit)
            if bn == 0:
                pred_out=pred
            else:
                pred_out+=pred
        return pred_out/self.bagging_num    
    
class XGB_SBBTree():
    """Stacking,
        Bootstap,
        Bagging----SBBTree"""
    def __init__(self, params, stacking_num, bagging_num, bagging_test_size, num_boost_round, early_stopping_rounds):
        """
        Initializes the SBBTree.
        Args:
          params : CAT params.
          stacking_num : k_flod stacking.
          bagging_num : bootstrap num.
          bagging_test_size : bootstrap sample rate.
          num_boost_round : boost num.
          early_stopping_rounds : early_stopping_rounds.
        """
        self.params = params
        self.stacking_num = stacking_num
        self.bagging_num = bagging_num
        self.bagging_test_size = bagging_test_size
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds

        self.model = xgb
        self.stacking_model = []
        self.bagging_model = []
        logger.info('XGB_SBBTree Model:%s'%(self.model))
        logger.info('params:%s'%(self.params))
        logger.info('stacking_num:%s'%(self.stacking_num) )
        logger.info('bagging_num:%s'%(self.bagging_num) )
        logger.info('bagging_test_size:%s'%(self.bagging_test_size))
        logger.info('num_boost_round:%s'%(self.num_boost_round))
        logger.info('early_stopping_rounds:%s'%(self.early_stopping_rounds))
    def fit(self, X, y):
        """ fit model. """
        if self.stacking_num > 1:
            layer_train = np.zeros((X.shape[0], 2))
            self.SK = KFold(n_splits=self.stacking_num, shuffle=True, random_state=1)
            for k,(train_index, test_index) in enumerate(self.SK.split(X, y)):
                X_train = X[train_index]
                y_train = y[train_index]
                X_test = X[test_index]
                y_test = y[test_index]

                param_test1 = {
                        	 'max_depth':[5,6],
                        	 # 'reg_alpha':[0.1,1],
                        	 'learning_rate':[0.05],}
            
                gsearch = GridSearchCV(xgb.XGBRegressor(**self.params),
                        param_grid = param_test1, scoring='neg_mean_squared_error',iid=False, cv=3, n_jobs=-1)
                gsearch.fit(X_train, y_train)
                logger.info('XGB_SBBTree Stacking:%s'%(k))
                # logger.info('gsearch.cv_results:%s'%(gsearch.cv_results_))
                logger.info('gsearch.best_params_:%s'%(gsearch.best_params_))
                logger.info('gsearch.best_score_:%s'%(gsearch.best_score_))
                logger.info('rmsle:%s'%(rmsle(gsearch.best_estimator_.predict(X_test),y_test)))                
                self.stacking_model.append(gsearch.best_estimator_)

                pred_y = gsearch.best_estimator_.predict(X_test)
                layer_train[test_index, 1] = pred_y
                if k == 0:
                    rmsles=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
                else:
                    rmsles+=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
            logger.info('stacking_mean_rmsle :%s'%(rmsles/self.bagging_num))
            X = np.hstack((X, layer_train[:,1].reshape((-1,1)))) 
        else:
            pass
        for bn in range(self.bagging_num):
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=self.bagging_test_size, random_state=bn)

            param_test1 = {
                        	 'max_depth':[6,8],
                        	 # 'reg_alpha':[0.1,0.05],
                        	 'learning_rate':[0.05],}
        
            gsearch = GridSearchCV(xgb.XGBRegressor(**self.params),
                    param_grid = param_test1, scoring='neg_mean_squared_error',iid=False, cv=3, n_jobs=-1)
            gsearch.fit(X_train, y_train)
            logger.info('XGB_SBBTree Bagging:%s'%(bn))
            # logger.info('gsearch.cv_results:%s'%(gsearch.cv_results_))
            logger.info('gsearch.best_params_:%s'%(gsearch.best_params_))
            logger.info('gsearch.best_score_:%s'%(gsearch.best_score_))
            logger.info('rmsle:%s'%(rmsle(gsearch.best_estimator_.predict(X_test),y_test)))                
            self.bagging_model.append(gsearch.best_estimator_)
            if bn == 0:
                rmsles=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
            else:
                rmsles+=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
        logger.info('bagging_mean_rmsle :%s'%(rmsles/self.bagging_num)) 
    def predict(self, X_pred):
        """ predict test data. """
        if self.stacking_num > 1:
            test_pred = np.zeros((X_pred.shape[0], self.stacking_num))
            for sn,gsearch in enumerate(self.stacking_model):
                pred = gsearch.predict(X_pred)
                test_pred[:, sn] = pred
            X_pred = np.hstack((X_pred, test_pred.mean(axis=1).reshape((-1,1))))  
        else:
            pass 
        for bn,gsearch in enumerate(self.bagging_model):
            pred = gsearch.predict(X_pred)
            if bn == 0:
                pred_out=pred
            else:
                pred_out+=pred
        return pred_out/self.bagging_num     
    
class CAT_SBBTree():
    """Stacking,
        Bootstap,
        Bagging----SBBTree"""
    def __init__(self, params, stacking_num, bagging_num, bagging_test_size, num_boost_round, early_stopping_rounds):
        """
        Initializes the SBBTree.
        Args:
          params : CAT params.
          stacking_num : k_flod stacking.
          bagging_num : bootstrap num.
          bagging_test_size : bootstrap sample rate.
          num_boost_round : boost num.
          early_stopping_rounds : early_stopping_rounds.
        """
        self.params = params
        self.stacking_num = stacking_num
        self.bagging_num = bagging_num
        self.bagging_test_size = bagging_test_size
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds

        self.model = CatBoostRegressor
        self.stacking_model = []
        self.bagging_model = []
        logger.info('CatBoost Model:%s'%(self.model))
        logger.info('params:%s'%(self.params))
        logger.info('stacking_num:%s'%(self.stacking_num) )
        logger.info('bagging_test_size:%s'%(self.bagging_test_size))
        logger.info('num_boost_round:%s'%(self.num_boost_round))
        logger.info('early_stopping_rounds:%s'%(self.early_stopping_rounds))
    def fit(self, X, y):
        """ fit model. """
        if self.stacking_num > 1:
            layer_train = np.zeros((X.shape[0], 2))
            self.SK = KFold(n_splits=self.stacking_num, shuffle=True, random_state=1)
            for k,(train_index, test_index) in enumerate(self.SK.split(X, y)):
                X_train = X[train_index]
                y_train = y[train_index]
                X_test = X[test_index]
                y_test = y[test_index]

                param_test1 = {'depth':[3,6],#3,6,8,10
                                'iterations':[300,500,1000],
                               'learning_rate':[0.05,0.03,0.01], 
                                'l2_leaf_reg':[3],#1,3,5,10
                                'border_count':[128]}#2,4,8,16,32,64
            
                gsearch = GridSearchCV(CatBoostRegressor(**self.params),
                        param_grid = param_test1, scoring='neg_mean_squared_error',iid=False, cv=3, n_jobs=-1)
                gsearch.fit(X_train, y_train)
                logger.info('CAT_SBBTree Stacking:%s'%(k))
                # logger.info('gsearch.cv_results:%s'%(gsearch.cv_results_))
                logger.info('gsearch.best_params_:%s'%(gsearch.best_params_))
                logger.info('gsearch.best_score_:%s'%(gsearch.best_score_))
                logger.info('rmsle:%s'%(rmsle(gsearch.best_estimator_.predict(X_test),y_test)))                    
                self.stacking_model.append(gsearch.best_estimator_)

                pred_y = gsearch.best_estimator_.predict(X_test)
                layer_train[test_index, 1] = pred_y
                if k == 0:
                    rmsles=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
                else:
                    rmsles+=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
            logger.info('stacking_mean_rmsle :%s'%(rmsles/self.bagging_num))
            X = np.hstack((X, layer_train[:,1].reshape((-1,1)))) 
        else:
            pass
        for bn in range(self.bagging_num):
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=self.bagging_test_size, random_state=bn)

            param_test1 = {'depth':[3,6],#3,6,8,10
                           # 'iterations':[300,500,1000],
                           'learning_rate':[0.05,0.03], 
                            'l2_leaf_reg':[3],#1,3,5,10
                            'border_count':[128]}#2,4,8,16,32,64
        
            gsearch = GridSearchCV(CatBoostRegressor(**self.params),
                    param_grid = param_test1, scoring='neg_mean_squared_error',iid=False, cv=3, n_jobs=-1)
            gsearch.fit(X_train, y_train)
            logger.info('CAT_SBBTree Bagging:%s'%(bn))
            # logger.info('gsearch.cv_results:%s'%(gsearch.cv_results_))
            logger.info('gsearch.best_params_:%s'%(gsearch.best_params_))
            logger.info('gsearch.best_score_:%s'%(gsearch.best_score_))
            logger.info('rmsle:%s'%(rmsle(gsearch.best_estimator_.predict(X_test),y_test)))                
            self.bagging_model.append(gsearch.best_estimator_)
            if bn == 0:
                rmsles=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
            else:
                rmsles+=rmsle(gsearch.best_estimator_.predict(X_test),y_test)
        logger.info('bagging_mean_rmsle :%s'%(rmsles/self.bagging_num)) 
    def predict(self, X_pred):
        """ predict test data. """
        if self.stacking_num > 1:
            test_pred = np.zeros((X_pred.shape[0], self.stacking_num))
            for sn,gsearch in enumerate(self.stacking_model):
                pred = gsearch.predict(X_pred)
                test_pred[:, sn] = pred
            X_pred = np.hstack((X_pred, test_pred.mean(axis=1).reshape((-1,1))))  
        else:
            pass 
        for bn,gsearch in enumerate(self.bagging_model):
            pred = gsearch.predict(X_pred)
            if bn == 0:
                pred_out=pred
            else:
                pred_out+=pred
        return pred_out/self.bagging_num        
    


def rmsle(y_log, y0_log):
    return np.sqrt(np.mean(np.square(y_log - y0_log)))


def random_forest_autotune(X,y):
    logger.info('-' * 50)
    logger.info('Random Forest Start train')
    logger.info('-' * 50)
    param_test = {
        'max_depth':[6,17],
        'max_features':['auto','sqrt'],
        'n_estimators': [500,1000]
     }
    logger.info('Param： %s'%(param_test))
    gsearch = GridSearchCV(RandomForestRegressor(),refit=True,
                           param_grid = param_test, scoring='neg_mean_squared_error',iid=True, cv=5, n_jobs=-1)
    logger.info('Fitting data')
    logger.info('-' * 50)
    gsearch.fit(X,y)
    logger.info(gsearch.cv_results_)
    logger.info(gsearch.best_params_)
    logger.info(gsearch.best_score_)
    logger.info('-' * 50)
    logger.info('Complete the training')
    logger.info(rmsle(gsearch.predict(X),y))
    return gsearch.best_estimator_

def xgb_autotune(X,y):
    logger.info('-' * 50)
    logger.info('XGBoost Start train')
    logger.info('-' * 50)
    param = {
	        'objective':'reg:squarederror',
	        'n_estimators':5000,
	        'learning_rate':0.05,
	        'gamma':0,
	        'max_depth':6,
	        'min_child_weight':1,
	        'colsample_bytree':0.5,
	        'subsample': 0.8, 
	        'verbose':1,
	        'reg_alpha':0}
    logger.info('Param： %s'%(param))
    param_test1 = {
	 'max_depth':[7,8],
	 'reg_alpha':[0.1,1],
	 'learning_rate':[0.05,0.1],
	}
    logger.info('Param_test: %s'%(param_test1))
    gsearch = GridSearchCV(xgb.XGBRegressor(objective=param['objective'],
                                            n_estimators=param['n_estimators'], 
                                            learning_rate = param['learning_rate'], 
                                            gamma=param['gamma'],
                                            colsample_bytree=param['colsample_bytree'], 
                                            subsample=param['subsample'], 
                                            reg_alpha=param['reg_alpha']
	                          ),
	                        param_grid = param_test1, scoring='neg_mean_squared_error',iid=False, cv=5, n_jobs=-1)
    logger.info('Fitting data')
    logger.info('-' * 50)    
    gsearch.fit(X,y)
    logger.info(gsearch.cv_results_)
    logger.info(gsearch.best_params_)
    logger.info(gsearch.best_score_)
    logger.info('-' * 50)  
    logger.info('Complete the training')
    logger.info(rmsle(gsearch.predict(X),y))
    return gsearch.best_estimator_


def cat_autotune(X,y):
    logger.info('-' * 50)
    logger.info('CatBoost Start train')
    logger.info('-' * 50)
    param ={
        'iterations': 500,
        'learning_rate':0.05,
        'l2_leaf_reg':3,
        'bagging_temperature':1,
        'random_strength':1,
        'depth':6,
        'rsm':1,
        'one_hot_max_size':2,
        'leaf_estimation_method':'Gradient',
        'fold_len_multiplier':2,
        'border_count':128,
        'verbose':0,
    }
    logger.info('Param： %s'%(param))
    param_test1 = {'depth':[5,6],#3,6,8,10
                   'iterations':[500,1000,2000],
                   'learning_rate':[0.05], 
                    'l2_leaf_reg':[3],#1,3,5,10
                    'border_count':[128]}#2,4,8,16,32,64
    logger.info('Param_test: %s'%(param_test1))
    gsearch = GridSearchCV(CatBoostRegressor(iterations=param['iterations'],
                                             depth=param['depth'], 
                                             learning_rate = param['learning_rate'], 
                                             l2_leaf_reg=param['l2_leaf_reg'],
                                             border_count=param['border_count'], 
            ),
            param_grid = param_test1, scoring='neg_mean_squared_error',iid=False, cv=5, n_jobs=-1)
    logger.info('Fitting data')
    logger.info('-' * 50)  
    gsearch.fit(X,y)
    logger.info(gsearch.cv_results_)
    logger.info(gsearch.best_params_)
    logger.info(gsearch.best_score_)
    logger.info('-' * 50) 
    logger.info('Complete the training')
    logger.info(rmsle(gsearch.predict(X),y))
    return gsearch.best_estimator_

def ensenble_xgb(X,y):
    logger.info('-' * 50)
    logger.info('Ensenble Start train')
    logger.info('-' * 50)
    param = {
	        'objective':'reg:squarederror',
	        'n_estimators':200,
	        'learning_rate':0.05,
	        'gamma':0,
	        'max_depth':3,
	        'min_child_weight':1,
	        'colsample_bytree':0.3,
	        'subsample': 0.6, 
	        'verbose':1,
	        'reg_alpha':0}
    logger.info('Param： %s'%(param))
    param_test1 = {
	 'max_depth':[7,8],
	 'reg_alpha':[0.1,1],
	 'learning_rate':[0.05,0.1],
	}
    logger.info('Param_test: %s'%(param_test1))
    gsearch = GridSearchCV(xgb.XGBRegressor(objective=param['objective'],
                                            n_estimators=param['n_estimators'], 
                                            learning_rate = param['learning_rate'], 
                                            gamma=param['gamma'],
                                            colsample_bytree=param['colsample_bytree'],
                                            subsample=param['subsample'], 
                                            reg_alpha=param['reg_alpha']
	                          ),
	                        param_grid = param_test1, scoring='neg_mean_squared_error',iid=False, cv=5, n_jobs=-1)
    logger.info('Fitting data')
    logger.info('-' * 50)
    gsearch.fit(X,y)
    logger.info(gsearch.cv_results_)
    logger.info(gsearch.best_params_)
    logger.info(gsearch.best_score_)
    logger.info('-' * 50)
    logger.info('Complete the training')
    logger.info(rmsle(gsearch.predict(X),y))
    return gsearch.best_estimator_      
    
  
    
    
    
    
    