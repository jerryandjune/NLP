# -*- coding: utf-8 -*-
"""
Created on Tue Dec  8 17:54:58 2020

@author: Jerry
"""

import logging
import time 


def logger():
    #创建logger，如果参数为空则返回root logger
    logger = logging.getLogger("Jerry")
    logger.setLevel(logging.DEBUG)  #设置logger日志等级

    #这里进行判断，如果logger.handlers列表为空，则添加，否则，直接去写日志
    if not logger.handlers:
        #创建handler
        fh = logging.FileHandler("./log/log%s.log"%(time.strftime('%Y-%m-%d-%H-%M-%S')),encoding="utf-8")
        ch = logging.StreamHandler()

        #设置输出日志格式
        formatter = logging.Formatter(
            fmt="%(asctime)s %(name)s %(filename)s %(message)s",
            datefmt="%Y/%m/%d %X"
            )

        #为handler指定输出格式
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)

        #为logger添加的日志处理器
        logger.addHandler(fh)
        logger.addHandler(ch)

    return logger #直接返回logger

logger = logger()


# logger.warning("泰拳警告")
# logger.info("提示")
# logger.error("错误")
# logger.debug("查错")