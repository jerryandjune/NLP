# -*- coding: utf-8 -*-
"""
Created on Tue Dec  8 17:54:58 2020

@author: Jerry
"""

import pandas as pd
import pickle
import numpy as np
import re, os, timeit
import matplotlib.pyplot as plt
from sklearn import ensemble 
from sklearn.metrics import mean_squared_error,make_scorer
import xgboost as xgb
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit, GridSearchCV, cross_val_score, train_test_split, KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn import preprocessing
from catboost import CatBoostRegressor
from sklearn.preprocessing import PolynomialFeatures
from logger import logger
from model import *

def load_data(train_path, test_path):
    """
    Load_data.
    Args:
        train_path : train data path.
        test_path : test data path.
    Return:
        DataFrame.
    """
    logger.info('正在读取训练集和测试集')
    df_train = pd.read_csv(train_path, parse_dates=['timestamp'])
    df_train['_data'] = 'train'   
    df_test = pd.read_csv(test_path, parse_dates=['timestamp'])
    df_test['_data'] = 'test'  
    
    logger.info('-'*50)
    logger.info('正在处理部分缺失值和异常值')
    df_train.columns = map(str.lower, df_train.columns)
    df_train.columns = map(str.strip, df_train.columns)    
    df_train[df_train['humidity']==888] = np.nan
    df_train.fillna(method='ffill',inplace=True) 

    df_test.columns = map(str.lower, df_test.columns)
    df_test.columns = map(str.strip, df_test.columns)  
    df_test.iloc[8696] = df_test.iloc[8695]
    
    logger.info('-'*50) 
    logger.info('正在合拼训练集和测试集')
    df = pd.concat([df_train,df_test])
    df = df.reset_index(drop=True) 
    
    logger.info('-'*50) 
    logger.info('数据合拼完成，返回数据')    
    return df

def extract_time_feature(df):
    """
    Extract time feature.
    Args:
        df : DataFrame.
    Return:
        DataFrame
    """    
    logger.info('-'*50) 
    logger.info('正在提取时间特征')
    df['year'] = df['timestamp'].dt.year
    df['month'] = df['timestamp'].dt.month
    df['day'] = df['timestamp'].dt.day
    df['hr'] = df['timestamp'].dt.hour
    df['date'] = df['timestamp'].dt.date
    df['dow'] = df['timestamp'].dt.dayofweek
    df['woy'] = df['timestamp'].dt.weekofyear
    logger.info('-'*50) 
    logger.info('提取完成，返回数据')    
    return df

def extract_feature(df):
    """
    Extract feature.
    Args:
        df : DataFrame.
    Return:
        DataFrame.
    """      
    logger.info('-'*50) 
    logger.info('正在提取类别特征')
    # 週末 and hour
    df['hr_categori'] = 0
    df.loc[(df.weekend == 1)&(df.hr <= 9), 'hr_categori'] = 1
    df.loc[(df.weekend == 1)&(df.hr >= 21), 'hr_categori'] = 1 
    df.loc[(df.weekend == 1)&(df.hr <= 18)&(df.hr >= 10), 'hr_categori'] = 2  
    df.loc[(df.weekend == 1)&(df.hr <= 19)&(df.hr >= 16), 'hr_categori'] = 2
       
    # 非週末 and hour
    # df['hr_categori'] = 'normal'
    df.loc[(df.weekend == 0)&(df.hr <= 6), 'hr_categori'] = 1  
    df.loc[(df.weekend == 0)&(df.hr >= 21), 'hr_categori'] = 1  
    df.loc[(df.weekend == 0)&(df.hr <= 9)&(df.hr >= 7), 'hr_categori'] = 2   
    df.loc[(df.weekend == 0)&(df.hr <= 19)&(df.hr >= 16), 'hr_categori'] = 2
    
    # month
    df['month_categori'] = 0
    df.loc[(df.month <= 3), 'month_categori'] = 1  
    df.loc[(df.month >= 11), 'month_categori'] = 1
    df.loc[(df.month <= 8)&(df.month >= 6), 'month_categori'] = 2
     
    # temp1    
    df['temp_categori'] = 1
    df.loc[df.temp1 <= 15, 'temp_categori'] = 1
    df.loc[(df.temp1 <= 20)&(df.temp1 > 15), 'temp_categori'] = 0
    df.loc[(df.temp1 < 33)&(df.temp1 >= 31), 'temp_categori'] = 0
    df.loc[(df.temp1 >= 33), 'temp_categori'] = 1
    
    # humidity    
    df['humi_categori'] = 0
    df.loc[(df.humidity <= 40), 'humi_categori'] = 1
    df.loc[(df.humidity >= 70), 'humi_categori'] = 2
       
    # wind speed  
    df['wind_categori'] = 0
    df.loc[(df['wind speed'] >= 15)&(df['wind speed'] <= 30), 'wind_categori'] = 1
    df.loc[(df['wind speed'] == 43), 'wind_categori'] = 1
    df.loc[(df['wind speed'] >= 51), 'wind_categori'] = 2
    df.loc[(df['wind speed'] <= 6), 'wind_categori'] = 2
    logger.info('-'*50) 
    logger.info('提取完成') 
    
    logger.info('-'*50) 
    logger.info('正在提取其他特征')  
    df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
    df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
    df['month_tan'] = np.tan(2 * np.pi * df['month'] / 12)
    
    # 增加一些天气code      
    weather_dict = {1 : 100,  2 : 100,  3 : 100,  4 : 100, 
                    7 : 200, 10 : 200, 26 : 200, 94 : 200}    
    df['weather_code']=df['weather'].replace(weather_dict)    
    df['is_night'] = 0
    df.loc[(df['hr'] < 8) | (df['hr'] > 20), 'is_night'] = 1
    df['is_non_workday'] = df['holiday'] + df['weekend']     
    
    # 添加一些public_holiday
    public_vacation_list = [
        "01-01","01-02","02-14","03-01","03-17","03-25","03-27","04-23", "05-30",
        "07-12","08-29","10-31","11-05","11-30","12-24","12-25","12-26","12-30","12-31"]
    df['date'] = df['date'].apply(lambda x: pd.Timestamp(x).strftime("%m-%d"))
    df['public_holiday'] = df['date'].apply(lambda x: 1 if x in public_vacation_list else 0)
    
    # christmas day and others
    df['holiday'] = df[['month', 'day', 'holiday']].apply(lambda x: (x['holiday'], 1)[x['month'] == 12 and x['day'] in [24, 25, 26, 31]], axis = 1)
    df['weekend'] = df[['month', 'day', 'weekend']].apply(lambda x: (x['weekend'], 0)[x['month'] == 12 and x['day'] in [24, 25, 31]], axis = 1)
    df['ideal'] = df[['temp1', 'wind speed']].apply(lambda x: (0, 1)[x['temp1'] > 27 and x['wind speed'] < 30], axis = 1)
    df['sticky'] = df[['humidity', 'weekend']].apply(lambda x: (0, 1)[x['weekend'] == 1 and x['humidity'] >= 60], axis = 1)
    logger.info('-'*50) 
    logger.info('提取完成') 
        
    # 创建多项式特征  
    logger.info('-'*50) 
    logger.info('正在提取多项式特征')     
    polynomial_interaction = PolynomialFeatures(degree=1, include_bias=False)
    polynomial_features = polynomial_interaction.fit_transform(df[['temp1','temp2','humidity','wind speed','month_sin','month_cos','month_tan']])
    df = pd.concat([df, pd.DataFrame(polynomial_features)], axis=1)    
    logger.info('-'*50) 
    logger.info('提取完成，返回数据')     
    return df

def split_data(df):
    """
    Split data.
    Args:
        df : DataFrame.
    Return:
        DataFrame.
    """      
    logger.info('-'*50) 
    logger.info('正在切分数据')
    # count 对数变换
    df['count_log'] = np.log1p(df['count'])
    # 筛选训练集
    train = df[df['_data']=='train']
    # 切分训练集和测试集
    train, test = train_test_split(train, test_size = 0.1, random_state = 0)   
    # 设置需要移除的列名
    remove_columns = ['timestamp','count','_data','count','count_log','year','date']
    # 获取需要保留的列名
    features_columns = [c for c in df.columns if c not in remove_columns]
    
    X_train, y_train = train[features_columns], train['count_log']
    X_test, y_test = test[features_columns], test['count_log'] 
    # 筛选预测数据
    predict_data = df[df['_data']=='test'][features_columns]
    logger.info('-'*50) 
    logger.info('切分完成，返回数据')    
    return X_train, y_train, X_test, y_test, predict_data


def get_all_model_predict(data, models, model_names):
    """
    Get all_model predict.
    Args:
      data : DataFrame.
      models : models list.
      model names : model names list.
    Return:
        DataFrame.
    """      
    predict = pd.DataFrame(data={method: [np.nan] * data.shape[0] for method in model_names})
    for i in range(len(models)):       
        if model_names[i]=='xgb_tree_model':
            predict[model_names[i]] = models[i].predict(data.values)
        else:
            predict[model_names[i]] = models[i].predict(data)
    return predict


def main():
    """
    Main Program.
    Args:
        None.
    Return:
        None.
    """  
    # 记录开始时间
    start = timeit.default_timer()
    # 设定训练集和测试集的文件路径
    train_path = './data/train_15.csv'
    test_path = './data/feature_16.csv'
    # 加载数据
    data = load_data(train_path, test_path)
    # 提取时间特征
    data = extract_time_feature(data)
    # 提取其他特征
    data = extract_feature(data)
    # 切分数据
    X_train, y_train, X_test, y_test, pred_data = split_data(data)
    
    # 开始训练
    logger.info('-'*50)
    logger.info('开始训练')    
    xgb_model = xgb_autotune(X_train, y_train)
    random_forest_model = random_forest_autotune(X_train, y_train)
    cat_model = cat_autotune(X_train, y_train)

    # 设置model和model name 列表
    models = [xgb_model, random_forest_model, cat_model]
    model_names=['xgb','random_forest','CatBoost']
    # 使用测试集评估模型rmsle
    rmsles=[]    
    logger.info('-'*50)
    logger.info('XGBoost test score')
    logger.info(rmsle(xgb_model.predict(X_test), y_test))
    rmsles.append(rmsle(xgb_model.predict(X_test), y_test))    
    
    logger.info('-'*50)
    logger.info('Random Forest test score')
    rmsles.append(rmsle(random_forest_model.predict(X_test), y_test))
    logger.info(rmsle(random_forest_model.predict(X_test), y_test))
    
    logger.info('-'*50)
    logger.info('Catboost test score')
    rmsles.append(rmsle(cat_model.predict(X_test), y_test))
    logger.info(rmsle(cat_model.predict(X_test), y_test))
    logger.info('-'*50)

    # 使用所有模型预测X_train结果
    logger.info('使用所有模型预测X_train结果')
    X_train_pred = get_all_model_predict(X_train, models, model_names)

    # 使用X_train预测的结果，使用XGBoost再训练一个模型
    logger.info('-'*50)
    logger.info('使用X_train预测的结果，使用XGBoost再训练一个模型')
    ensenble_model = ensenble_xgb(X_train_pred, y_train)

    # 使用X_test验证训练效果
    logger.info('-'*50)
    logger.info('使用X_test验证训练效果')
    X_test_pred = get_all_model_predict(X_test, models, model_names)
    logger.info('-'*50)
    logger.info('ensenble_model test score')
    logger.info(rmsle(ensenble_model.predict(X_test_pred), y_test))
    
    logger.info('-'*50)
    logger.info('正在使用所有模型预测2016年数据')
    # 使用所有模型预测2016年数据
    pred_result = get_all_model_predict(pred_data, models, model_names)
    
    logger.info('-'*50)
    logger.info('正在使用ensenble_model预测以上模型预测的结果')
    # 使用Ensenble xgb预测以上模型预测的结果
    pred_log = ensenble_model.predict(pred_result)
     
    logger.info('-'*50)
    logger.info('正在还原预测结果')
    # 还原预测结果
    pred = np.expm1(pred_log) 
    
    logger.info('-'*50)
    logger.info('正在导出预测结果')
    # 导出数据
    pred_data['count'] = pred
    pred_data['id'] = np.arange(8716,17416,1)
    final_df = pred_data[['id', 'count']].copy()
    final_df.to_csv('./result/predict_%.8f.csv'%(rmsle(ensenble_model.predict(X_test_pred), y_test)), index=False)
    
    logger.info('-'*50)
    logger.info('预测结果已导出，路径如下： %s'%(os.getcwd()+'\\result\\'))    
    logger.info('-'*50)
    logger.info('用时：%.2f 秒'%(timeit.default_timer() - start))
    logger.info('-'*50)
    logger.info('Finish')    

    
    
if __name__ == '__main__':
    main()
    


